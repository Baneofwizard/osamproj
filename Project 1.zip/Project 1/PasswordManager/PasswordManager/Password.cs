﻿using System.Collections.Generic;

namespace PasswordManager
{
    public class Password
    {
        public string Value { get; set; }
        public int StrengthNum { get; set; }
        public string StrengthText { get; set; }
        public string LastReset { get; set; }

    }// end class Password

    public class Account
    {
        public string Description { get; set; }
        public string UserId { get; set; }
        public string LoginUrl { get; set; }
        public string AccountNum { get; set; }

        public List<Password> PasswordList = new List<Password> { };



    } // end class Account


}