﻿///*
// * Program:         ShoppingList ***** SAMPLE SOLUTION *****
// * File:            Program.cs
// * Date:            April 28, 2020
// * Course:          INFO-3138
// * Description:     Builds a shopping list file in JSON format based on user inputs.
// * 
// *                  Also uses the Newtonsoft.Json.Schema package to validate each Item
// *                  object against the schema in "item_schema.json" before adding it to 
// *                  the shopping_list collection.
// */

//using System;

//using System.Collections.Generic;   // List<> class
//using System.IO;                    // File class
//using Newtonsoft.Json;              // JsonConvert class
//using Newtonsoft.Json.Schema;       // JSchema class
//using Newtonsoft.Json.Linq;         // JObject class
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PasswordManager
//{
//    class tester
//    {
//        // Declare constants for the file path names 
//        static void Main(string[] args)
//        {
//            var ProjectLocation = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
//            var SlnLocation = (ProjectLocation + "\\" + "PasswordManager.sln");

//            Console.Write("Let's prepare a shopping list!");

//            //  Load the contents of the schema file (using SCHEMA_FILE) into 
//            //  a string variable
//            string json_schema;
//            if (ReadFile(SCHEMA_FILE, out json_schema))
//            {
//                // Create a collection to hold all items
//                List<Item> shopping_list = new List<Item>();

//                bool done;
//                do
//                {
//                    Console.Write("\n\nEnter a password: ");
//                    string pwText = Console.ReadLine();

//                    // Get the user to populate a shopping list item
//                    Item item = new Item();

//                    bool valid;
//                    do
//                    {
//                        //Console.Write("\tDescription: ");
//                        //item.Description = Console.ReadLine();
//                        do
//                        {
//                            int x = Console.WindowWidth;
//                            int y = Console.WindowHeight;
//                            for (int i = 0; i < x; i++)
//                            {
//                                Console.WriteLine("-");
//                            }
//                            try
//                            {
//                                // PasswordTester class demonstration
//                                PasswordTester pw = new PasswordTester(pwText);
//                                Console.WriteLine("That password is " + pw.StrengthLabel);
//                                Console.WriteLine("That password has a strength of " + pw.StrengthPercent + "%");
//                            }
//                            catch (ArgumentException)
//                            {
//                                Console.WriteLine("ERROR: Invalid password format");
//                            }

//                            Console.Write("\nTest another password? (y/n): ");
//                            done = Console.ReadKey().KeyChar != 'y';

//                        } while (!done);
//                        Console.Write("\tUnits: ");
//                        item.Units = Console.ReadLine();

//                        // Validate the item object against the schema using the ValidateItem() method
//                        // and IF the object is invalid, repeat the user-input code above to repopulate the 
//                        // object until it's valid
//                        valid = ValidateItem(item, json_schema);

//                        if (!valid)
//                            Console.WriteLine("\nERROR:\tItem data does not match the required format. Please try again.\n");

//                    } while (!valid);
//                    // Add this item to the list
//                    shopping_list.Add(item);

//                    Console.Write("\nAdd another item? (y/n): ");
//                    done = Console.ReadKey().KeyChar != 'y';
//                } while (!done);

//                // Write the shopping list to a file
//                string json_all = JsonConvert.SerializeObject(shopping_list);
//                try
//                {
//                    File.WriteAllText(LIST_FILE, json_all);
//                    Console.WriteLine($"\n\nYour shopping list has been written to {LIST_FILE}.\n");
//                }
//                catch (IOException ex)
//                {
//                    Console.WriteLine($"\n\nERROR: {ex.Message}.\n");
//                }
//            }
//            else
//            {
//                // Read operation for schema failed
//                Console.WriteLine("\nERROR:\tUnable to read the schema file.");
//            }

//        } // end Main()

//        // Validates an item object against a schema (incomplete)
//        private static bool ValidateItem(Item item, string json_schema)
//        {
//            // Convert item object to a JSON string 
//            string json_data = JsonConvert.SerializeObject(item);

//            // Validate the data string against the schema contained in the 
//            // json_schema parameter. Also, modify or replace the following 
//            // return statement to return 'true' if item is valid, or 'false' 
//            // if invalid.
//            JSchema schema = JSchema.Parse(json_schema);
//            JObject itemObj = JObject.Parse(json_data);
//            return itemObj.IsValid(schema);

//        } // end ValidateItem()

//        // Attempts to read the json file specified by 'path' into the string 'json'
//        // Returns 'true' if successful or 'false' if it fails
//        private static bool ReadFile(string path, out string json)
//        {
//            try
//            {
//                // Read JSON file data 
//                json = File.ReadAllText(path);
//                return true;
//            }
//            catch
//            {
//                json = null;
//                return false;
//            }
//        } // end ReadFile()

//    } // end class Program

//    // Definition of the Item class
//    class Item
//    {
//        public string Description { get; set; }
//        public double Quantity { get; set; }
//        public string Units { get; set; }
//        public string Value { get; set; }
//        public int StrengthNum { get; set; }
//        public string StrengthText { get; set; }
//        public string LastReset { get; set; }

//    } // end class Item

//}
