﻿/*
 * Program:         PasswordManager.exe
 * Module:          PasswordManager.cs
 * Date:            2022-06-06
 * Author:          Kieran Primeau, Agnita Paul
 * Description:     Final Code for the password manager with all parts functional.
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Schema;
using Newtonsoft.Json.Linq;
using System.Runtime.InteropServices;

namespace PasswordManager
{
    class Program
    {
        private const int MF_BYCOMMAND = 0x00000000;
        public const int SC_MINIMIZE = 0xF020;
        public const int SC_MAXIMIZE = 0xF030;
        public const int SC_SIZE = 0xF000;//resize
        public static int width = Console.WindowWidth;
        public static int height = Console.WindowHeight;
        public static int count=-1, listnum=-1;
        public static string choices = "", jsonFileStr = "";
        public static List<Account> accounts = new List<Account>();
        public static JArray jData;
        public static string ProjectLocation = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
        public static string Fpath = (ProjectLocation + "\\" + "password-schema1.json");
        public static StreamReader file = File.OpenText(Fpath);
        public static JsonTextReader reader = new JsonTextReader(file);
        public static JSchema schema = JSchema.Load(reader);
        [DllImport("user32.dll")]
        public static extern int DeleteMenu(IntPtr hMenu, int nPosition, int wFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        private static extern IntPtr GetConsoleWindow();
        static void Main(string[] args)
        {
            IntPtr handle = GetConsoleWindow();
            IntPtr sysMenu = GetSystemMenu(handle, false);

            if (handle != IntPtr.Zero)
            {
                //DeleteMenu(sysMenu, SC_MINIMIZE, MF_BYCOMMAND);
                DeleteMenu(sysMenu, SC_MAXIMIZE, MF_BYCOMMAND);
                DeleteMenu(sysMenu, SC_SIZE, MF_BYCOMMAND);//resize
            }
            DateTime dateNow = DateTime.Now;
            Console.Write("PASSWORD MANAGEMENT SYSTEM (STARTING CODE), " + dateNow.ToShortDateString());
            file.Close();
            var Fpath2 = (ProjectLocation + "\\" + "accounts.json");
            jsonFileStr = File.ReadAllText(Fpath2);
            jData = JArray.Parse(jsonFileStr);
            if (ReadFile(Fpath, out _))
            {
                while (true)
                {
                    buildDesign();
                    buildTitle();
                    buildDesign();
                    selectChoice();
                    titlePt2();
                    buildDesign();
                    Console.Write("Select an Option: ");
                    var menuVar = Console.ReadLine();
                    var isNumeric = int.TryParse(menuVar, out int num);
                    if ((isNumeric == true) && (num <= jData.Count) && (num > 0))
                    {
                        buildList(jData, num);
                        while (menuVar.ToLower() != "m")
                        {
                            buildQuestion();
                            Console.Write("Select an Option: ");
                            menuVar = Console.ReadLine();
                            switch (menuVar.ToLower())
                            {
                                case "p":
                                    {
                                        changePassword(jData, num-1);
                                        break;
                                    }
                                case "d":
                                    {
                                        RemoveCode(num);
                                        menuVar = "m";
                                        break;
                                    }
                                case "m":
                                    {
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }
                            }
                        }
                    }
                    else
                    {
                        switch (menuVar.ToLower())
                        {
                            case "a":
                                {
                                    AddCode();
                                    break;
                                }
                            case "x":
                                {
                                    Environment.Exit(0);
                                    break;
                                }
                            default:
                                break;
                        }
                    }
                }
            }
            else
            {
                // Read operation for schema failed
                Console.WriteLine("ERROR:\tUnable to read the schema file.");
            }
            Console.WriteLine("\n");
        }//main class
        private static bool ReadFile(string path, out string json)
        {
            try
            {
                // Read JSON file data 
                json = File.ReadAllText(path);
                return true;
            }
            catch
            {
                json = null;
                return false;
            }
        } // end ReadFile()
        private static void buildDesign()
        {
            Console.WriteLine();
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("+");
                }
                if (i > 0 && i < width - 1)
                {
                    Console.Write("-");
                }
                if (i == width)
                {
                    Console.Write("+");
                }
            }
        }
        private static void buildDesignNoSpace()
        {
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("+");
                }
                if (i > 0 && i < width - 1)
                {
                    Console.Write("-");
                }
                if (i == width)
                {
                    Console.Write("+");
                }
            }
        }
        private static void buildTitle()
        {
            Console.WriteLine();
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("|");
                }
                if (i < ((width / 2) - 5))
                {
                    Console.Write(" ");
                }
                if (i == width / 2)
                {
                    Console.Write("Account Entries");
                }
                if (i > ((width / 2)) && i < width - 11)
                {
                    Console.Write(" ");
                }
                if (i == width - 1)
                {
                    Console.Write("|");
                }
            }
        }
        private static void titlePt2()
        {
            Console.WriteLine();
            Console.Write("|                                        Enter a number from the list above to view                                    |");
            Console.Write("|                                        Enter the letter a to add to the list                                         |");
            Console.Write("|                                        Enter the letter x to exit the app                                            |");
        }
        private static void selectChoice()
        {
            for (int i = 0; i < jData.Count; i++)
            {
                choices = buildChoice(jData, "$.Description", i);
                Console.WriteLine($" {i + 1}: {choices}");
            }
            buildDesignNoSpace();
        }
        private static string buildChoice(JArray jArray, string desc, int cnt)
        {
                JObject temp = (JObject)jArray[cnt];
                IEnumerable<JToken> results = temp.SelectTokens(desc);
                StringBuilder sb = new StringBuilder("");
                int num = 0;

                bool first = true;
                foreach (JToken r in results)
                {
                    string next = r.ToString();
                    if (!first)
                        sb.Append(", ");
                    else
                        first = false;

                    if (sb.ToString().Length + next.Length - num * width > width)
                    {
                        sb.Append("\n");
                        ++num;
                    }
                    sb.Append(next);
                }
                return sb.ToString();
            }
        private static void AddCode()
        {
            Account account = new Account();
            bool validBoolUrl = false;
            string temp = "";
            Console.WriteLine("Please key-in values for the following fields... \n");
            do
            {
                while (temp.Length <= 0)
                {
                    Console.Write("Description:                ");
                    temp = Console.ReadLine();
                    account.Description = temp;
                }
                temp = "";
                while (temp.Length <= 0)
                {
                    Console.Write("User ID:                    ");
                    temp = Console.ReadLine();
                    account.UserId = temp;
                }
                temp = "";
                string passE = "";
                while (passE.Length <= 0)
                {
                    Console.Write("Password:                   ");
                    passE = Console.ReadLine();
                }
                while (temp.Length <= 0)
                {
                    Console.Write("Login url:                  ");
                    temp = Console.ReadLine();
                    account.LoginUrl = temp; 
                }
                temp = "";
                while (temp.Length <= 0)
                {
                    Console.Write("Account #:                  ");
                    temp = Console.ReadLine();
                    account.AccountNum = temp;
                }
                string validUrl = account.LoginUrl;
                if (validUrl.Substring(0, 4) == "http")
                {
                    PasswordTester passValue = new PasswordTester(passE);
                    string tempPass = passValue.Value;
                    string tempNum = ""+passValue.StrengthPercent;
                    string tempText = passValue.StrengthLabel;
                    string tempLR = "" + DateTime.Now;
                    string holder = "{\n";
                    holder += "\"Description\": \"" + account.Description + "\",\n";
                    holder += "\"UserId\": \"" + account.UserId + "\",\n";
                    holder += "\"LoginUrl\": \"" + account.LoginUrl + "\",\n";
                    holder += "\"AccountNum\": \"" + account.AccountNum + "\",\n";
                    holder += "\"Password\": {\n\"Value\": \"" + tempPass.Trim() + "\",\n";
                    holder += "\"StrengthNum\": \"" + tempNum + "\",\n";
                    holder += "\"StrengthText\": \"" + tempText + "\",\n";
                    holder += "\"LastReset\": \"" + tempLR + "\",\n";
                    holder += "}\n}";
                    var ProjLoc = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
                    var Fpath3 = ProjLoc + "\\" + "accounts.json";
                    holder = "[\n" + holder + "\n]";
                    JArray tmp = JArray.Parse(holder);
                    bool valid = tmp.IsValid(schema);
                    if (valid==true)
                    {
                        jData.Add(tmp[0]);
                        File.WriteAllText(Fpath3, jData + "");
                        validBoolUrl = true;
                    }
                    else 
                    {
                        Console.WriteLine("Error: Invalid account information entered. Please try again... ");
                        break;
                    }
                }
            } while (!validBoolUrl);
            buildDesign();
            buildTitle();
            buildDesign();
            titlePt2();
            buildDesign();
        }
        private static void RemoveCode(int num)
        {
            Console.WriteLine("Confirm? (y) or (n):");
            string c = Console.ReadLine();
            if (c == "y")
            {
                jData[num - 1].Remove();
                string file = "[\n";
                for (int i = 0; i < jData.Count; i++)
                {
                    file += jData[i].ToString();
                    if (i != jData.Count - 1)
                    {
                        file += ",";
                    }
                    file += "\n";
                }
                file += "]";
                var ProjLoc = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
                var Fpath3 = ProjLoc + "\\" + "accounts.json";
                File.WriteAllText(Fpath3, file);
            }
            
        }
        private static void buildList(JArray jArray, int n)
        {
            Console.WriteLine();
            Console.Write(" " + n + ". " + buildChoice(jArray, "$.Description", n - 1));
            Console.WriteLine();
            Console.WriteLine();
            Console.Write(" User ID: " + buildChoice(jArray, "$.UserId", n - 1));
            Console.WriteLine();
            Console.Write(" Password: " + buildChoice(jArray, "$.Password.Value", n - 1));
            Console.WriteLine();
            Console.Write(" Password Strength: " + buildChoice(jArray, "$.Password.StrengthText", n - 1) + " (" + buildChoice(jArray, "$.Password.StrengthNum", n - 1) + ")");
            Console.WriteLine();
            Console.Write(" Password Reset: " + buildChoice(jArray, "$.Password.LastReset", n - 1));
            Console.WriteLine();
            Console.Write(" Login URL: " + buildChoice(jArray, "$.LoginUrl", n - 1));
            Console.WriteLine();
            Console.Write(" Account #: " + buildChoice(jArray, "$.AccountNum", n - 1));
            Console.WriteLine();
        }
        private static void buildQuestion()
        {
            buildDesign();
            Console.WriteLine();
            Console.Write("|                                        Enter p to change this password.                                              |");
            Console.Write("|                                        Enter d to delete this entry.                                                 |");
            Console.Write("|                                        Enter m to return to the menu.                                                |"); 
            buildDesign();
        }
        private static void changePassword(JArray jData, int num)
        {
            string passE = "";
            while (passE.Length <= 0)
            {
                Console.Write("Update Password:                   ");
                passE = Console.ReadLine();
            }
            string jParse = jData[num].ToString();
            PasswordTester pt = new PasswordTester(passE);
            jParse = jParse.Replace(buildChoice(jData, "$.Password.StrengthText", num), pt.StrengthLabel);
            jParse = jParse.Replace(buildChoice(jData, "$.Password.Value", num), passE.Trim());
            jParse = jParse.Replace(buildChoice(jData, "$.Password.StrengthNum", num), ""+pt.StrengthPercent);
            jParse = jParse.Replace(buildChoice(jData, "$.Password.LastReset", num), "" + DateTime.Now);
            JObject updatedPass = JObject.Parse(jParse);
            jData[num].Replace(updatedPass);
            string file = "[\n";
            for (int i = 0; i < jData.Count; i++)
            {
                file += jData[i].ToString();
                if (i != jData.Count - 1)
                {
                    file += ",";
                }
                file += "\n";
            }
            file += "]";
            var ProjLoc = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
            var Fpath3 = ProjLoc + "\\" + "accounts.json";
            File.WriteAllText(Fpath3, file);
            buildDesignNoSpace();
            buildList(jData, num+1);
        }
    } // end class
}
