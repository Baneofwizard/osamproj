﻿/*
 * Program:         PasswordManager.exe
 * Module:          PasswordManager.cs
 * Date:            <enter a date>
 * Author:          <enter your name>
 * Description:     Some free starting code for INFO-3138 project 1, the Password Manager
 *                  application. All it does so far is demonstrate how to obtain the system date 
 *                  and how to use the PasswordTester class provided.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;   // File class
using Newtonsoft.Json;              // JsonConvert class
using Newtonsoft.Json.Schema;       // JSchema  class
using Newtonsoft.Json.Linq;         // JObject class
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace PasswordManager
{
    class Program
    {
        private const int MF_BYCOMMAND = 0x00000000;
        public const int SC_MINIMIZE = 0xF020;
        public const int SC_MAXIMIZE = 0xF030;
        public const int SC_SIZE = 0xF000;//resize
        public static int width = Console.WindowWidth;
        public static int height = Console.WindowHeight;
        public static int option = 99, count=-1, listnum=-1;
        public static List<string> choices = new List<string>();
        public static List<Account> accounts = new List<Account>();
        [DllImport("user32.dll")]
        public static extern int DeleteMenu(IntPtr hMenu, int nPosition, int wFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        private static extern IntPtr GetConsoleWindow();
        static void Main(string[] args)
        {
            IntPtr handle = GetConsoleWindow();
            IntPtr sysMenu = GetSystemMenu(handle, false);

            if (handle != IntPtr.Zero)
            {
                //DeleteMenu(sysMenu, SC_MINIMIZE, MF_BYCOMMAND);
                DeleteMenu(sysMenu, SC_MAXIMIZE, MF_BYCOMMAND);
                DeleteMenu(sysMenu, SC_SIZE, MF_BYCOMMAND);//resize
            }
            // System date demonstration
            DateTime dateNow = DateTime.Now;
            Console.Write("PASSWORD MANAGEMENT SYSTEM (STARTING CODE), " + dateNow.ToShortDateString());
            // Attempt to read the json schema file into a string variable
            string json_schema;
            var ProjectLocation = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
            var Fpath = (ProjectLocation + "\\" + "password-schema1.json");
            var Fpath2 = (ProjectLocation + "\\" + "accounts.json");
            while (true)
            {
                Account acc = new Account();
                //int c1 = -1;
                Console.WriteLine();
                var readin = File.ReadAllText(Fpath2);

                string json_str = File.ReadAllText(Fpath2);
                acc = JsonConvert.DeserializeObject<Account>(json_str);
                break;
            }
            //accounts.Add();
            if (ReadFile(Fpath, out json_schema))
            {
                buildDesign();
                buildTitle();
                buildDesign();
                titlePt2();
                buildDesign();
                bool done = false;
                while (option != 9999)
                {
                    listnum = 0;
                    for (int i = 0; i < choices.Count(); i++)
                    {
                        listnum++;
                        buildChoice(choices[i], listnum-1);
                    }
                    selectChoice();
                    switch (Console.ReadLine())
                    {
                        case "a":
                            {
                                string temp = "";
                                Console.Write("Enter the of the thing u want to add: ");
                                temp = Console.ReadLine();
                                AddCode(temp);
                                break;
                            }
                        case "x":
                            {
                                Environment.Exit(0);
                                break;
                            }
                        case "1994":
                            {
                                Console.Write("\nEnter a password: ");
                                string pwText = Console.ReadLine();
                                try
                                {
                                    // PasswordTester class demonstration
                                    PasswordTester pw = new PasswordTester(pwText);
                                    Console.WriteLine("That password is " + pw.StrengthLabel);
                                    Console.WriteLine("That password has a strength of " + pw.StrengthPercent + "%");
                                }
                                catch (ArgumentException)
                                {
                                    Console.WriteLine("ERROR: Invalid password format");
                                }
                                Console.Write("\nTest another password? (y/n): ");
                                done = Console.ReadKey().KeyChar != 'y';
                                break;
                            }
                        default:
                            break;
                    }
                }
            }
            else
            {
                // Read operation for schema failed
                Console.WriteLine("ERROR:\tUnable to read the schema file.");
            }
            Console.WriteLine("\n");
        }//main class

        // Attempts to read the json file specified by 'path' into the string 'json'
        // Returns 'true' if successful or 'false' if it fails
        private static bool ReadFile(string path, out string json)
        {
            try
            {
                // Read JSON file data 
                json = File.ReadAllText(path);
                return true;
            }
            catch
            {
                json = null;
                return false;
            }
        } // end ReadFile()


        private static bool ValidateTeamData(string json_data, string json_schema, out IList<string> messages)
        {
            JSchema schema = JSchema.Parse(json_schema);
            JObject team = JObject.Parse(json_data);
            return team.IsValid(schema, out messages);
        } // end ValidateTeamData()
        private static void buildDesign()
        {
            Console.WriteLine();
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("+");
                }
                if (i > 0 && i < width - 1)
                {
                    Console.Write("-");
                }
                if (i == width)
                {
                    Console.Write("+");
                }
            }
        }
        private static void buildTitle()
        {
            Console.WriteLine();
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("|");
                }
                if (i < ((width / 2) - 5))
                {
                    Console.Write(" ");
                }
                if (i == width / 2)
                {
                    Console.Write("Account Entries");
                }
                if (i > ((width / 2)) && i < width - 11)
                {
                    Console.Write(" ");
                }
                if (i == width - 1)
                {
                    Console.Write("|");
                }
            }
        }
        private static void titlePt2()
        {
            Console.WriteLine();
            Console.Write("|                                        Enter a number from the list above to view                                    |");
            Console.Write("|                                        Enter the letter a to add to the list                                         |");
            Console.Write("|                                        Enter the letter x to exit the app                                            |");
        }
        private static void selectChoice()
        {
            string temp = "";
            int numOptions = choices.Count();
            for(int i=0;i<numOptions; i++)
            {
                if(i==0)
                {
                    buildDesign();
                }
                Console.WriteLine(i +". "+ choices[i]);
            }
            Console.WriteLine();
            Console.Write("Select an Option: ");
        }
        private static void buildChoice(string value, int cnt)
        {
            //buildDesign();
            Console.WriteLine();
            for (int i = 0; i <= width; i++)
            {
                if (i == 0)
                {
                    Console.Write("|");
                }
                if (i < ((width / 2) - 5))
                {
                    Console.Write(" ");
                }
                if (i == width / 2)
                {
                    Console.Write(cnt +". " + value);
                }
                if (i > ((width / 2)) && i < width - 11)
                {
                    Console.Write(" ");
                }
                if (i == width - 1)
                {
                    Console.Write("|\n");
                }
            }
            //buildDesign();
        }
        private static void AddCode(string value)
        {
            Account account = new Account();
            Password password = new Password();
            bool validBoolUrl = false;
            Console.WriteLine("Please key-in values for the following fields... \n");
            do
            {
                Console.Write("Description:                ");
                account.Description = Console.ReadLine();
                Console.Write("User ID:                    ");
                account.UserId = Int32.Parse(Console.ReadLine());
                Console.Write("Password:                   ");
                password.Value = Console.ReadLine();
                Console.Write("Login url:                  ");
                account.LoginUrl = Console.ReadLine();
                Console.Write("Account #:                  ");
                string validUrl = account.LoginUrl;
                if (validUrl.Substring(0, 4) == "http")
                {
                    accounts.Add(account);
                    validBoolUrl = true;
                    choices.Add(value);
                }
                else
                {
                    Console.WriteLine("Error: Invalid account information entered. Please try again... ");
                }
                Console.WriteLine("Please key-in values for the following fields... \n");
            } while (!validBoolUrl);
            //choices.Add(value);
            //accounts.Add(account);
            buildDesign();
            buildTitle();
            buildDesign();
            titlePt2();
            buildDesign();
        }
    } // end class
}
