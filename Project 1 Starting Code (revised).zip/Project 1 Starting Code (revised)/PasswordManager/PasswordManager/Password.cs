﻿using System.Collections.Generic;

namespace PasswordManager
{
    public class Password
    {
        public string Value { get; set; }
        public int StrengthNum { get; set; }
        public string StrengthText { get; set; }
        public string LastReset { get; set; }

    }// end class Password

    public class Account
    {
        public string Description { get; set; }
        public int UserId { get; set; }
        public string LoginUrl { get; set; }
        public string AccountNum { get; set; }

        List<Password> PasswordList = null;

    } // end class Account


}
